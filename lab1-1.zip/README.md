# Lab 1 (Andrew Lau and Ryan Kirkpatrick)

To compile and run
```
> make
> java SchoolSearch
```